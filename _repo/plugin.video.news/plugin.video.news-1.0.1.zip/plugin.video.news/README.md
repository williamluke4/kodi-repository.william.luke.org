Youtube Live News Streams
=======================
version 1.0.1

### Summary

Addon finds and plays first live link found for the following search terms

* Al Jazeera English
* CNN
* KTN
* CitizenTV
* NTV