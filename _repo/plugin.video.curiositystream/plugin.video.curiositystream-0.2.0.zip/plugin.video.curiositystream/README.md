# plugin.video.curiositystream
Kodi addon to play video content from the curiositystream.com site.

## Usage
download the zip file and install it on Kodi.

